import React from 'react';

export default function About() {
  return (
    <div className='d-flex justify-content-center mt-5'>
        <h2>Vendemos zapatillas desde 1999.</h2>
    </div>
  )
}
